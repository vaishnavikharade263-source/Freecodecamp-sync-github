// popup.js
// Handles the popup UI: loading/saving settings, asking the content script
// for the current editor code, and asking the background script to push it
// to GitHub. Shows success/failure alerts and inline status text.

const ownerInput = document.getElementById("owner");
const repoInput = document.getElementById("repo");
const tokenInput = document.getElementById("token");
const messageInput = document.getElementById("message");
const autoSyncInput = document.getElementById("autoSync");
const syncBtn = document.getElementById("syncBtn");
const statusEl = document.getElementById("status");

function setStatus(text, type = "info") {
  statusEl.textContent = text;
  statusEl.className = `status-${type}`;
}

// Restore previously saved settings so the user doesn't have to retype them
// every time, and so the content script (which reads storage directly) can
// auto-sync even while the popup is closed.
chrome.storage.local.get(
  ["fccSync_owner", "fccSync_repo", "fccSync_token", "fccSync_message", "fccSync_autoSync"],
  (data) => {
    if (data.fccSync_owner) ownerInput.value = data.fccSync_owner;
    if (data.fccSync_repo) repoInput.value = data.fccSync_repo;
    if (data.fccSync_token) tokenInput.value = data.fccSync_token;
    if (data.fccSync_message) messageInput.value = data.fccSync_message;
    autoSyncInput.checked = !!data.fccSync_autoSync;
  }
);

function saveSettings() {
  chrome.storage.local.set({
    fccSync_owner: ownerInput.value.trim(),
    fccSync_repo: repoInput.value.trim(),
    fccSync_token: tokenInput.value.trim(),
    fccSync_message: messageInput.value.trim(),
    fccSync_autoSync: autoSyncInput.checked,
  });
}

// Persist settings as soon as they change, not just when "Sync now" is
// clicked — the content script needs up-to-date storage values to auto-sync
// even if the popup is never opened again.
[ownerInput, repoInput, tokenInput, messageInput].forEach((el) => {
  el.addEventListener("change", saveSettings);
});
autoSyncInput.addEventListener("change", () => {
  saveSettings();
  setStatus(
    autoSyncInput.checked
      ? "Auto-sync enabled. Leave the FCC tab open — pushes happen automatically after you pause typing."
      : "Auto-sync disabled.",
    "info"
  );
});

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

syncBtn.addEventListener("click", async () => {
  const owner = ownerInput.value.trim();
  const repo = repoInput.value.trim();
  const token = tokenInput.value.trim();
  const message = messageInput.value.trim() || "Sync FreeCodeCamp project";

  if (!owner || !repo || !token) {
    setStatus("Please fill in owner, repo, and token.", "err");
    alert("Please fill in the repo owner, repo name, and GitHub token before syncing.");
    return;
  }

  saveSettings();

  syncBtn.disabled = true;
  setStatus("Reading code from FreeCodeCamp editor…", "info");

  try {
    const tab = await getActiveTab();

    if (!tab || !tab.url || !tab.url.includes("freecodecamp.org")) {
      throw new Error("Please open this popup while on a freecodecamp.org challenge page.");
    }

    // Ask the content script (already injected via manifest content_scripts)
    // for the current code. If it hasn't loaded yet, we inject it manually
    // as a fallback and retry.
    let codeResponse;
    try {
      codeResponse = await chrome.tabs.sendMessage(tab.id, { type: "FCC_GET_CODE" });
    } catch (err) {
      // Content script may not be injected yet (e.g. page loaded before
      // the extension was installed). Inject it and try again.
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["content.js"],
      });
      codeResponse = await chrome.tabs.sendMessage(tab.id, { type: "FCC_GET_CODE" });
    }

    if (!codeResponse || !codeResponse.success) {
      throw new Error(codeResponse?.error || "Could not find any code in the FreeCodeCamp editor.");
    }

    const code = codeResponse.code;
    if (!code || !code.trim()) {
      throw new Error("The editor appears to be empty.");
    }

    setStatus("Pushing code to GitHub…", "info");

    // Ask the background script to do the actual GitHub API call.
    const pushResponse = await chrome.runtime.sendMessage({
      type: "FCC_PUSH_TO_GITHUB",
      payload: { owner, repo, token, message, code, projectTitle: codeResponse.projectTitle },
    });

    if (!pushResponse || !pushResponse.success) {
      throw new Error(pushResponse?.error || "Unknown error while pushing to GitHub.");
    }

    setStatus(`Synced! Saved as ${pushResponse.path}`, "ok");
    alert(`✅ Success!\n\nYour code was pushed to:\n${owner}/${repo}/${pushResponse.path}`);
  } catch (err) {
    console.error("FCC Sync error:", err);
    setStatus(err.message || "Something went wrong.", "err");
    alert(`❌ Sync failed:\n\n${err.message || err}`);
  } finally {
    syncBtn.disabled = false;
  }
});
