// background.js (MV3 service worker)
// Receives the scraped code from the popup and pushes it to GitHub as a new
// file using the Contents API:
//   PUT /repos/:owner/:repo/contents/:path

/**
 * Encode a UTF-8 string to base64, the way the GitHub Contents API expects.
 * btoa() alone chokes on non-Latin1 characters, so we go through
 * encodeURIComponent first.
 */
function toBase64(str) {
  const utf8Bytes = new TextEncoder().encode(str);
  let binary = "";
  utf8Bytes.forEach((byte) => {
    binary += String.fromCharCode(byte);
  });
  return btoa(binary);
}

function slugify(text) {
  return (text || "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
    .slice(0, 40);
}

async function pushFileToGithub({ owner, repo, token, message, code, projectTitle }) {
  const timestamp = Date.now();
  const slug = slugify(projectTitle);
  const filename = slug
    ? `fcc_project_${slug}_${timestamp}.js`
    : `fcc_project_${timestamp}.js`;
  const path = filename;

  const apiUrl = `https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(
    repo
  )}/contents/${encodeURIComponent(path)}`;

  const body = {
    message: message || `Sync FreeCodeCamp project: ${projectTitle || filename}`,
    content: toBase64(code),
  };

  let response;
  try {
    response = await fetch(apiUrl, {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/vnd.github+json",
        "Content-Type": "application/json",
        "X-GitHub-Api-Version": "2022-11-28",
      },
      body: JSON.stringify(body),
    });
  } catch (networkErr) {
    throw new Error(
      "Network error reaching the GitHub API. Check your internet connection and try again."
    );
  }

  let data = null;
  try {
    data = await response.json();
  } catch (e) {
    // Some error responses may not be JSON; ignore parse failure here.
  }

  if (!response.ok) {
    const apiMessage = data && data.message ? data.message : response.statusText;

    if (response.status === 401) {
      throw new Error("GitHub rejected the token (401 Unauthorized). Check that it's valid and not expired.");
    }
    if (response.status === 403) {
      throw new Error(
        `GitHub denied the request (403 Forbidden): ${apiMessage}. Check token scopes/rate limits.`
      );
    }
    if (response.status === 404) {
      throw new Error(
        `Repository not found (404): ${owner}/${repo}. Check the owner/repo name and that the token has access.`
      );
    }
    if (response.status === 422) {
      throw new Error(`GitHub validation error (422): ${apiMessage}`);
    }
    throw new Error(`GitHub API error (${response.status}): ${apiMessage}`);
  }

  return {
    path: data?.content?.path || path,
    htmlUrl: data?.content?.html_url || null,
  };
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "FCC_PUSH_TO_GITHUB") {
    const { owner, repo, token, message, code, projectTitle } = request.payload || {};

    if (!owner || !repo || !token || !code) {
      sendResponse({ success: false, error: "Missing required fields (owner, repo, token, or code)." });
      return true;
    }

    pushFileToGithub({ owner, repo, token, message, code, projectTitle })
      .then((result) => {
        sendResponse({ success: true, path: result.path, htmlUrl: result.htmlUrl });
      })
      .catch((err) => {
        console.error("FCC Sync push error:", err);
        sendResponse({ success: false, error: err.message || "Unknown error pushing to GitHub." });
      });

    return true; // async sendResponse
  }
});
