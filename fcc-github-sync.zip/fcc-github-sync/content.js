// content.js
// Runs on freecodecamp.org pages. Its job is to pull the current code out of
// whatever editor FCC is using (modern FCC uses Monaco; older forks / some
// challenge types still use CodeMirror) and hand it back to the popup.

/**
 * Try to read code from a Monaco editor instance exposed on window.monaco.
 * FCC's Monaco instances aren't always exposed globally, so this is a
 * best-effort attempt.
 */
function getMonacoCode() {
  try {
    if (window.monaco && window.monaco.editor) {
      const models = window.monaco.editor.getModels();
      if (models && models.length) {
        return models.map((m) => m.getValue()).join("\n\n// ---\n\n");
      }
    }
  } catch (e) {
    // ignore, fall through to DOM scraping
  }
  return null;
}

/**
 * Scrape a Monaco editor's rendered DOM lines. Monaco renders visible lines
 * inside elements with class "view-line"; because of virtualization this can
 * miss lines that are scrolled out of view, but it's a solid fallback when
 * we can't reach the model directly.
 */
function getMonacoDomCode() {
  const viewLines = document.querySelectorAll(".monaco-editor .view-lines .view-line");
  if (viewLines.length) {
    return Array.from(viewLines)
      .map((line) => line.textContent)
      .join("\n");
  }
  return null;
}

/**
 * Scrape a CodeMirror 5/6 editor's DOM.
 */
function getCodeMirrorCode() {
  // CodeMirror 5
  const cm5Lines = document.querySelectorAll(".CodeMirror-code .CodeMirror-line");
  if (cm5Lines.length) {
    return Array.from(cm5Lines)
      .map((line) => line.textContent)
      .join("\n");
  }

  // CodeMirror 6
  const cm6Lines = document.querySelectorAll(".cm-content .cm-line");
  if (cm6Lines.length) {
    return Array.from(cm6Lines)
      .map((line) => line.textContent)
      .join("\n");
  }

  return null;
}

/**
 * Last-resort fallback: a plain <textarea> holding the code (some legacy
 * challenge views render this way, and it's also handy for a hidden CM/Monaco
 * backing textarea in certain configurations).
 */
function getTextareaCode() {
  const textareas = document.querySelectorAll("textarea");
  for (const ta of textareas) {
    if (ta.value && ta.value.trim().length > 0) {
      return ta.value;
    }
  }
  return null;
}

function getProjectTitle() {
  const heading = document.querySelector("h1, .challenge-title, [data-cy='challenge-title']");
  if (heading && heading.textContent.trim()) {
    return heading.textContent.trim();
  }
  return document.title.replace(/\s*\|\s*freeCodeCamp.*$/i, "").trim();
}

function getCurrentCode() {
  return (
    getMonacoCode() ||
    getMonacoDomCode() ||
    getCodeMirrorCode() ||
    getTextareaCode()
  );
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "FCC_GET_CODE") {
    try {
      const code = getCurrentCode();
      if (!code) {
        sendResponse({
          success: false,
          error:
            "Couldn't locate an editor on this page. Make sure you're on a freeCodeCamp challenge page with the code editor visible.",
        });
        return true;
      }
      sendResponse({
        success: true,
        code,
        projectTitle: getProjectTitle(),
      });
    } catch (err) {
      sendResponse({ success: false, error: err.message || "Failed to read editor code." });
    }
    return true; // keep the message channel open for the async-safe sendResponse above
  }
});

// ---------------------------------------------------------------------------
// Auto-sync
//
// When enabled (via the popup's "Enable auto-sync" checkbox), this watches
// the editor DOM for changes and pushes a new commit to GitHub automatically
// — no popup interaction required. To avoid hammering the GitHub API on
// every keystroke, changes are debounced (wait for a pause in typing) and
// throttled with a minimum cooldown between pushes. A push is also skipped
// entirely if the code hasn't actually changed since the last sync.
// ---------------------------------------------------------------------------

const AUTO_SYNC_DEBOUNCE_MS = 8000; // wait for 8s of inactivity after an edit
const AUTO_SYNC_COOLDOWN_MS = 45000; // never push more often than every 45s

let autoSyncEnabled = false;
let autoSyncSettings = null; // { owner, repo, token, message }
let debounceTimer = null;
let lastSyncedCode = null;
let lastSyncTime = 0;
let observerStarted = false;

function showToast(text, type = "info") {
  const existing = document.getElementById("fcc-sync-toast");
  if (existing) existing.remove();

  const colors = {
    info: "#2563eb",
    ok: "#16a34a",
    err: "#dc2626",
  };

  const toast = document.createElement("div");
  toast.id = "fcc-sync-toast";
  toast.textContent = text;
  Object.assign(toast.style, {
    position: "fixed",
    bottom: "20px",
    right: "20px",
    zIndex: 2147483647,
    background: colors[type] || colors.info,
    color: "#fff",
    padding: "10px 14px",
    borderRadius: "8px",
    fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
    fontSize: "13px",
    boxShadow: "0 4px 14px rgba(0,0,0,0.25)",
    maxWidth: "300px",
    lineHeight: "1.4",
  });
  document.body.appendChild(toast);

  setTimeout(() => {
    toast.style.transition = "opacity 0.4s ease";
    toast.style.opacity = "0";
    setTimeout(() => toast.remove(), 400);
  }, 4000);
}

function refreshAutoSyncSettings() {
  chrome.storage.local.get(
    ["fccSync_owner", "fccSync_repo", "fccSync_token", "fccSync_message", "fccSync_autoSync"],
    (data) => {
      autoSyncEnabled = !!data.fccSync_autoSync;
      autoSyncSettings = {
        owner: data.fccSync_owner || "",
        repo: data.fccSync_repo || "",
        token: data.fccSync_token || "",
        message: data.fccSync_message || "Auto-sync from FreeCodeCamp",
      };

      if (autoSyncEnabled) {
        ensureObserverStarted();
      }
    }
  );
}

// Keep settings fresh if the user tweaks them in the popup while this tab
// stays open.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (
    "fccSync_owner" in changes ||
    "fccSync_repo" in changes ||
    "fccSync_token" in changes ||
    "fccSync_message" in changes ||
    "fccSync_autoSync" in changes
  ) {
    refreshAutoSyncSettings();
  }
});

function scheduleAutoSync() {
  if (!autoSyncEnabled) return;
  if (debounceTimer) clearTimeout(debounceTimer);
  debounceTimer = setTimeout(attemptAutoSync, AUTO_SYNC_DEBOUNCE_MS);
}

async function attemptAutoSync() {
  if (!autoSyncEnabled || !autoSyncSettings) return;

  const { owner, repo, token, message } = autoSyncSettings;
  if (!owner || !repo || !token) {
    showToast("Auto-sync is on, but owner/repo/token aren't set. Open the extension popup to fill them in.", "err");
    return;
  }

  const now = Date.now();
  if (now - lastSyncTime < AUTO_SYNC_COOLDOWN_MS) {
    // Still cooling down from the last push — try again after the debounce
    // window once the cooldown has elapsed.
    const remaining = AUTO_SYNC_COOLDOWN_MS - (now - lastSyncTime);
    debounceTimer = setTimeout(attemptAutoSync, remaining + 500);
    return;
  }

  let code;
  try {
    code = getCurrentCode();
  } catch (err) {
    return; // editor not ready yet; next mutation will retry
  }

  if (!code || !code.trim()) return;
  if (code === lastSyncedCode) return; // nothing actually changed

  try {
    const response = await chrome.runtime.sendMessage({
      type: "FCC_PUSH_TO_GITHUB",
      payload: {
        owner,
        repo,
        token,
        message,
        code,
        projectTitle: getProjectTitle(),
      },
    });

    if (response && response.success) {
      lastSyncedCode = code;
      lastSyncTime = Date.now();
      showToast(`✅ Auto-synced to ${owner}/${repo}/${response.path}`, "ok");
    } else {
      showToast(`❌ Auto-sync failed: ${response?.error || "Unknown error"}`, "err");
    }
  } catch (err) {
    showToast(`❌ Auto-sync failed: ${err.message || err}`, "err");
  }
}

function ensureObserverStarted() {
  if (observerStarted) return;
  observerStarted = true;

  const target = document.body;
  const observer = new MutationObserver(() => {
    scheduleAutoSync();
  });
  observer.observe(target, { childList: true, subtree: true, characterData: true });

  // Also catch keystrokes directly, since some editors update the DOM in
  // ways MutationObserver on subtree/characterData can miss (e.g. canvas-
  // rendered text in some Monaco configurations).
  document.addEventListener("keyup", scheduleAutoSync, true);
}

// Kick things off once the content script loads.
refreshAutoSyncSettings();
