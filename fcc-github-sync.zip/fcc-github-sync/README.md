# FCC → GitHub Sync

A Chrome extension that scrapes your current freeCodeCamp editor code and
pushes it as a new file to a GitHub repository.

## Install (unpacked / dev mode)

1. Unzip this folder somewhere on disk.
2. Open `chrome://extensions` in Chrome.
3. Enable **Developer mode** (top right).
4. Click **Load unpacked** and select the `fcc-github-sync` folder.

## Setup

1. Create a GitHub [Personal Access Token](https://github.com/settings/tokens)
   with the **repo** scope (classic token) or **Contents: read & write**
   (fine-grained token, scoped to the target repo).
2. Make sure the target repository already exists on GitHub.

## Use

1. Open any freeCodeCamp challenge page with the code editor visible.
2. Click the extension icon.
3. Fill in:
   - **Repo owner** — your GitHub username or org
   - **Repo name** — an existing repository
   - **GitHub token** — the PAT you generated
   - **Commit message** — optional, defaults to "Sync FreeCodeCamp project"
4. Click **Sync current project to GitHub**.

Each sync creates a **new** file (it never overwrites previous syncs) named:

```
fcc_project_<slugified-title>_<timestamp>.js
```

or, if a title can't be detected:

```
fcc_project_<timestamp>.js
```

## How it works

- `content.js` runs on `freecodecamp.org` pages and reads the code from
  whichever editor FCC is using — it tries, in order: the Monaco editor
  model API, the rendered Monaco DOM, CodeMirror 5/6 DOM, and finally any
  populated `<textarea>` as a last resort.
- `popup.js` collects your settings, asks the content script for the code,
  and asks the background script to push it.
- `background.js` (the MV3 service worker) calls the GitHub REST API:
  `PUT /repos/:owner/:repo/contents/:path` with the base64-encoded file
  content, creating the new file and commit.

## Notes / limitations

- Your token is stored in `chrome.storage.local`, which is local to your
  browser profile — it is not sent anywhere except directly to
  `api.github.com`.
- Monaco's DOM-based scraping only reliably captures visible lines if the
  model API isn't accessible; for very long files, prefer challenges where
  `window.monaco` is reachable, or scroll through the file once before
  syncing so all lines have rendered.
- Every sync writes a brand-new, timestamped file rather than updating an
  existing one, so your repo will accumulate one file per sync by design.
